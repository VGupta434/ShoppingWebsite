export interface User{
    userId?: string;
    name:string;
    technology:string
}